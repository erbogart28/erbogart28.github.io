class StarterController < ApplicationController
  def home
  end
end
