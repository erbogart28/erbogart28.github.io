module HomeHelper
    def admin?
  self.admin
end
end