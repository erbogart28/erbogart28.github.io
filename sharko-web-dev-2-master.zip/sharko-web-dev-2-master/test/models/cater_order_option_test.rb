require 'test_helper'

class CaterOrderOptionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
